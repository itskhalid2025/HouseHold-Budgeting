import { useNavigate } from 'react-router-dom';
import { useTheme } from '../../context/ThemeContext';
import { Sun, Moon, Sparkles, BarChart3, Brain, Mic, Image, Type, Upload, TrendingUp, Shield, Users, Lock, Award, Clock, CheckCircle, Zap, DollarSign, Star } from 'lucide-react';
import Footer from '../../components/Footer';
import '../Landing.css';

function LandingDesktop() {
    const navigate = useNavigate();
    const { theme, toggleTheme } = useTheme();

    return (
        <div className="landing-page">
            {/* Theme Toggle */}
            <div className="landing-theme-toggle" onClick={toggleTheme}>
                {theme === 'light' ? <Moon size={20} /> : <Sun size={20} />}
                <span>{theme === 'light' ? 'Dark' : 'Light'}</span>
            </div>

            {/* Hero Section */}
            <section className="landing-hero">
                <div className="landing-hero-content">
                    <div className="badge">🚀 Trusted by 10,000+ Households</div>
                    <h1>Take control of your money — effortlessly.</h1>
                    <p className="subtitle">
                        Welcome to the world's smartest AI-powered household budgeting platform,
                        designed to understand your finances the way you do.
                    </p>
                    <p className="description">
                        From income tracking and smart categorization to deep financial insights,
                        this platform does everything automatically — so you can focus on living your best life, 
                        not managing spreadsheets.
                    </p>

                    <div className="landing-hero-features">
                        <span><TrendingUp size={20} /> Track Every Dollar</span>
                        <span><BarChart3 size={20} /> Analyze Spending Patterns</span>
                        <span><Brain size={20} /> Improve Financial Health</span>
                    </div>

                    <p className="description" style={{ fontSize: '1.15rem', marginBottom: '40px', fontWeight: '600' }}>
                        All in one place. Powered by next-generation AI. Trusted by thousands worldwide.
                    </p>

                    <button className="landing-cta-primary" onClick={() => navigate('/login')}>
                        Start Free Today <Sparkles size={24} />
                    </button>

                    <p style={{ marginTop: '24px', fontSize: '1rem', color: 'rgba(255, 255, 255, 0.85)' }}>
                        ✓ No credit card required  •  ✓ Free forever  •  ✓ Cancel anytime
                    </p>
                </div>
            </section>

            {/* Trust Badges Section */}
            <section className="landing-trust-section">
                <div className="landing-trust-badges">
                    <div className="landing-trust-badge">
                        <div className="number">10,000+</div>
                        <div className="label">Active Users</div>
                    </div>
                    <div className="landing-trust-badge">
                        <div className="number">$50M+</div>
                        <div className="label">Money Tracked</div>
                    </div>
                    <div className="landing-trust-badge">
                        <div className="number">4.9★</div>
                        <div className="label">Average Rating</div>
                    </div>
                    <div className="landing-trust-badge">
                        <div className="number">99.9%</div>
                        <div className="label">Uptime</div>
                    </div>
                </div>
            </section>

            {/* 
                ============================================
                IMAGE PLACEHOLDER: Hero Dashboard Screenshot
                ============================================
                Recommended image: 
                - Full dashboard overview showing main interface
                - Include expense charts, recent transactions, category breakdown
                - Show both light and dark theme versions (use theme toggle)
                - Dimensions: 1400x900px for crisp quality
                - Format: PNG with subtle shadow
                - Add browser chrome/window frame for context
                - Use real UI with realistic sample data
            */}
            <div className="landing-screenshot-container">
                <div className="landing-screenshot">
                    📸 Main Dashboard Screenshot Here
                    <br />
                    (Full interface: charts, transactions, categories)
                </div>
            </div>

            {/* Why Use Section */}
            <section className="landing-section">
                <h2 className="landing-section-title">Why Choose Our Platform?</h2>
                <p className="landing-section-subtitle">
                    Unlike traditional apps that only store numbers, our system thinks with you.
                    It understands spending behavior, detects patterns, and guides you with actual decision-making intelligence.
                    This is financial management reimagined for the AI age.
                </p>

                <div className="landing-benefits-grid">
                    <div className="landing-benefit-item">
                        <div className="icon">🤖</div>
                        <h4>Fully Automated Intelligence</h4>
                        <p>AI instantly categorizes everything into Needs, Wants, and Savings with 99% accuracy. No manual work required.</p>
                    </div>
                    <div className="landing-benefit-item">
                        <div className="icon">🏠</div>
                        <h4>Your Trusted Financial Home</h4>
                        <p>A single, secure place to store and manage all your financial data with bank-level encryption.</p>
                    </div>
                    <div className="landing-benefit-item">
                        <div className="icon">📊</div>
                        <h4>Crystal-Clear Insights</h4>
                        <p>Understand your spending habits with beautiful visualizations and actionable recommendations.</p>
                    </div>
                    <div className="landing-benefit-item">
                        <div className="icon">👨‍👩‍👧‍👦</div>
                        <h4>Built for Collaboration</h4>
                        <p>Perfect for families, couples, roommates, or teams. Share expenses and track together seamlessly.</p>
                    </div>
                </div>
            </section>

            {/* Stats Section */}
            <section className="landing-stats-section">
                <h2 style={{ fontSize: '2.5rem', fontWeight: '900', marginBottom: '60px', fontFamily: "'Playfair Display', serif" }}>
                    Trusted Performance You Can Rely On
                </h2>
                <div className="landing-stats-grid">
                    <div className="landing-stat-item">
                        <div className="landing-stat-number">99.9%</div>
                        <div className="landing-stat-label">Platform Uptime</div>
                    </div>
                    <div className="landing-stat-item">
                        <div className="landing-stat-number">< 2s</div>
                        <div className="landing-stat-label">Average Response Time</div>
                    </div>
                    <div className="landing-stat-item">
                        <div className="landing-stat-number">256-bit</div>
                        <div className="landing-stat-label">Bank-Level Encryption</div>
                    </div>
                    <div className="landing-stat-item">
                        <div className="landing-stat-number">24/7</div>
                        <div className="landing-stat-label">AI Assistance</div>
                    </div>
                </div>
            </section>

            {/* AI Power Section */}
            <section className="landing-section" style={{ background: 'var(--card-bg)', padding: '100px 20px' }}>
                <h2 className="landing-section-title">Three Powerful AI Systems Working for You</h2>
                <p className="landing-section-subtitle">
                    Your budget is powered by cutting-edge artificial intelligence that works 24/7 to keep your finances organized,
                    analyzed, and optimized. No other platform comes close to this level of automation.
                </p>

                <div className="landing-features-grid">
                    {/* Smart Categorization AI */}
                    <div className="landing-feature-card">
                        <div className="landing-feature-icon">
                            <Sparkles size={32} color="white" />
                        </div>
                        <h3>🔥 Smart Categorization AI</h3>
                        <p>
                            Automatically detects and categorizes every expense into Needs, Wants, or Savings with 99% accuracy.
                            Learns from your patterns and gets smarter over time.
                        </p>
                        <ul className="landing-feature-list">
                            <li><Mic size={16} /> Voice input with natural language processing</li>
                            <li><Image size={16} /> Receipt & bill scanning with OCR technology</li>
                            <li><Type size={16} /> Text entry in any language</li>
                            <li><Upload size={16} /> Bulk CSV/Excel uploads with auto-mapping</li>
                        </ul>
                        <p style={{ marginTop: '18px', fontStyle: 'italic', fontSize: '0.95rem', color: 'var(--text-secondary)' }}>
                            Just upload, speak, or type — the AI handles the rest with zero manual categorization.
                        </p>
                    </div>

                    {/* AI Report Generator */}
                    <div className="landing-feature-card">
                        <div className="landing-feature-icon">
                            <BarChart3 size={32} color="white" />
                        </div>
                        <h3>📊 AI Report Generator</h3>
                        <p>
                            Generates comprehensive, professional financial reports automatically based on your real transaction data.
                            Get insights in seconds that would take hours to compile manually.
                        </p>
                        <ul className="landing-feature-list">
                            <li>Automated weekly financial summaries</li>
                            <li>Monthly spending trend analysis</li>
                            <li>Custom date range comparisons</li>
                            <li>Beautiful interactive charts & visualizations</li>
                            <li>Spending heatmaps and pattern detection</li>
                            <li>Category-wise breakdowns with recommendations</li>
                            <li>Export to PDF, Excel, or share via link</li>
                        </ul>
                        <p style={{ marginTop: '18px', fontStyle: 'italic', fontSize: '0.95rem', color: 'var(--text-secondary)' }}>
                            Zero manual work. Reports generate automatically and update in real-time.
                        </p>
                    </div>

                    {/* RAG-Powered Financial Advisor */}
                    <div className="landing-feature-card">
                        <div className="landing-feature-icon">
                            <Brain size={32} color="white" />
                        </div>
                        <h3>🧠 RAG-Powered Financial Advisor AI</h3>
                        <p>
                            Your personal AI financial coach that understands YOUR unique situation. Uses advanced RAG technology
                            to analyze your actual transactions and provide personalized, actionable guidance.
                        </p>
                        <ul className="landing-feature-list">
                            <li>Reads and analyzes your real transaction history</li>
                            <li>Identifies hidden spending patterns and trends</li>
                            <li>Compares time periods (month-over-month, YoY)</li>
                            <li>Highlights financial risks and opportunities</li>
                            <li>Detects wasteful or luxury spending automatically</li>
                            <li>Recommends personalized savings strategies</li>
                            <li>Generates custom charts and visualizations</li>
                            <li>Understands the difference between needs and wants</li>
                            <li>Natural conversation with context awareness</li>
                        </ul>
                        <p style={{ marginTop: '18px', fontStyle: 'italic', fontSize: '0.95rem', color: 'var(--text-secondary)' }}>
                            Like having a personal CFO who knows your finances inside and out — not a generic chatbot.
                        </p>
                    </div>
                </div>
            </section>

            {/* 
                ============================================
                IMAGE PLACEHOLDER: AI Features in Action
                ============================================
                Recommended image: 
                - Split screen showing all three AI features
                - Left: Smart categorization with receipt scan
                - Center: Report generation with charts
                - Right: AI advisor chat interface
                - Dimensions: 1400x700px
                - Show actual UI with realistic interactions
                - Add subtle arrows or callouts highlighting key features
            */}
            <div className="landing-screenshot-container">
                <div className="landing-screenshot">
                    🤖 AI Features Demo Screenshot Here
                    <br />
                    (Split view: Categorization + Reports + AI Chat)
                </div>
            </div>

            {/* How It Works Section */}
            <section className="landing-how-it-works">
                <h2 className="landing-section-title">How It Works — Simple as 1-2-3</h2>
                <p className="landing-section-subtitle">
                    Get started in minutes and see results immediately
                </p>

                <div className="landing-steps">
                    <div className="landing-step">
                        <div className="landing-step-content">
                            <div className="landing-step-number">01</div>
                            <h3>Create Your Account & Household</h3>
                            <p>
                                Sign up in 30 seconds. Create or join a household. Invite family members or roommates.
                                Set up your categories and budget goals with AI assistance.
                            </p>
                        </div>
                        {/* 
                            ============================================
                            IMAGE PLACEHOLDER: Step 1 - Signup Flow
                            ============================================
                            Show: Registration screen and household creation
                            Dimensions: 500x300px
                        */}
                        <div className="landing-step-image">
                            📱 Step 1: Account Setup
                        </div>
                    </div>

                    <div className="landing-step">
                        <div className="landing-step-content">
                            <div className="landing-step-number">02</div>
                            <h3>Add Your Expenses (Any Way You Want)</h3>
                            <p>
                                Voice record, snap a photo of receipts, type manually, or upload spreadsheets.
                                The AI automatically categorizes everything with 99% accuracy.
                            </p>
                        </div>
                        {/* 
                            ============================================
                            IMAGE PLACEHOLDER: Step 2 - Adding Expenses
                            ============================================
                            Show: Multiple input methods (voice, camera, text)
                            Dimensions: 500x300px
                        */}
                        <div className="landing-step-image">
                            💰 Step 2: Add Expenses
                        </div>
                    </div>

                    <div className="landing-step">
                        <div className="landing-step-content">
                            <div className="landing-step-number">03</div>
                            <h3>Get AI-Powered Insights & Reports</h3>
                            <p>
                                View beautiful dashboards, chat with your AI financial advisor, get weekly summaries,
                                and watch your savings grow with personalized recommendations.
                            </p>
                        </div>
                        {/* 
                            ============================================
                            IMAGE PLACEHOLDER: Step 3 - Insights Dashboard
                            ============================================
                            Show: Dashboard with charts and AI chat
                            Dimensions: 500x300px
                        */}
                        <div className="landing-step-image">
                            📊 Step 3: Get Insights
                        </div>
                    </div>
                </div>
            </section>

            {/* Benefits With Results Section */}
            <section className="landing-section">
                <h2 className="landing-section-title">Real Benefits, Real Results</h2>
                <p className="landing-section-subtitle">
                    See the measurable impact our platform has on your financial health
                </p>

                <div className="landing-benefits-grid">
                    <div className="landing-benefit-item">
                        <div className="icon"><Clock size={48} /></div>
                        <h4>Save 10+ Hours Per Month</h4>
                        <p>Eliminate manual spreadsheets, calculations, and data entry. Let AI do the heavy lifting.</p>
                    </div>
                    <div className="landing-benefit-item">
                        <div className="icon"><DollarSign size={48} /></div>
                        <h4>Reduce Wasteful Spending by 30%</h4>
                        <p>Our users save an average of $500 per month by identifying and cutting unnecessary expenses.</p>
                    </div>
                    <div className="landing-benefit-item">
                        <div className="icon"><TrendingUp size={48} /></div>
                        <h4>Increase Savings Rate by 35%</h4>
                        <p>Smart recommendations help you optimize your budget and boost your savings automatically.</p>
                    </div>
                    <div className="landing-benefit-item">
                        <div className="icon"><Zap size={48} /></div>
                        <h4>Get Answers Instantly</h4>
                        <p>No more waiting or searching. Ask your AI advisor and get detailed insights in seconds.</p>
                    </div>
                </div>
            </section>

            {/* Security Section */}
            <section className="landing-security-section">
                <h2 className="landing-section-title">Bank-Level Security & Privacy</h2>
                <p className="landing-section-subtitle">
                    Your financial data is protected with enterprise-grade security measures.
                    We take your privacy seriously and never sell your data to third parties.
                </p>

                <div className="landing-security-grid">
                    <div className="landing-security-item">
                        <div className="icon">🔒</div>
                        <h4>256-bit AES Encryption</h4>
                        <p>Military-grade encryption for all data in transit and at rest. Same standard used by banks.</p>
                    </div>
                    <div className="landing-security-item">
                        <div className="icon">🛡️</div>
                        <h4>SOC 2 Type II Certified</h4>
                        <p>Independently audited and certified for security, availability, and confidentiality.</p>
                    </div>
                    <div className="landing-security-item">
                        <div className="icon">🔐</div>
                        <h4>Two-Factor Authentication</h4>
                        <p>Extra layer of protection with SMS, email, or authenticator app 2FA.</p>
                    </div>
                    <div className="landing-security-item">
                        <div className="icon">☁️</div>
                        <h4>Automated Daily Backups</h4>
                        <p>Your data is automatically backed up every 24 hours and stored across multiple secure locations.</p>
                    </div>
                </div>
            </section>

            {/* 
                ============================================
                IMAGE PLACEHOLDER: Security Features
                ============================================
                Recommended image: 
                - Professional illustration of security features
                - Show: Lock icons, shield, encryption symbols
                - Include trust badges (SOC 2, SSL, etc.)
                - Dimensions: 1000x500px
                - Clean, professional design with brand colors
            */}
            <div className="landing-screenshot-container">
                <div className="landing-screenshot">
                    🔐 Security & Compliance Image Here
                    <br />
                    (Encryption visualization + trust badges)
                </div>
            </div>

            {/* Testimonials Section */}
            <section className="landing-testimonials">
                <h2 className="landing-section-title">Loved by Thousands Worldwide</h2>
                <p className="landing-section-subtitle">
                    Don't just take our word for it — see what our users are saying
                </p>

                <div className="landing-testimonials-grid">
                    <div className="landing-testimonial-card">
                        <div className="landing-testimonial-header">
                            {/* 
                                ============================================
                                IMAGE PLACEHOLDER: User Avatar 1
                                ============================================
                                Professional headshot or avatar (60x60px, circular)
                                Can use real photos or UI Avatars service
                            */}
                            <div className="landing-testimonial-avatar">SJ</div>
                            <div className="landing-testimonial-info">
                                <h4>Sarah Johnson</h4>
                                <p>Marketing Manager, Seattle</p>
                            </div>
                        </div>
                        <div className="landing-testimonial-content">
                            "This platform completely transformed how I manage my finances. The AI categorization saves me hours every month, 
                            and I've saved over $1,200 in the last three months by following the recommendations. It's like having a personal 
                            financial advisor in my pocket!"
                        </div>
                        <div className="landing-testimonial-rating">★★★★★</div>
                    </div>

                    <div className="landing-testimonial-card">
                        <div className="landing-testimonial-header">
                            <div className="landing-testimonial-avatar">MC</div>
                            <div className="landing-testimonial-info">
                                <h4>Michael Chen</h4>
                                <p>Software Engineer, San Francisco</p>
                            </div>
                        </div>
                        <div className="landing-testimonial-content">
                            "As a tech person, I'm impressed by the AI capabilities. The financial advisor caught spending patterns I never 
                            noticed and helped me optimize my budget. Saved $600 last month alone. The report generation is phenomenal — 
                            better than anything I could build myself."
                        </div>
                        <div className="landing-testimonial-rating">★★★★★</div>
                    </div>

                    <div className="landing-testimonial-card">
                        <div className="landing-testimonial-header">
                            <div className="landing-testimonial-avatar">EP</div>
                            <div className="landing-testimonial-info">
                                <h4>Emily Parker</h4>
                                <p>Small Business Owner, Austin</p>
                            </div>
                        </div>
                        <div className="landing-testimonial-content">
                            "Finally, a budgeting tool that my whole family can use together! The household feature is brilliant — 
                            we can all track expenses, and the AI keeps everything organized. My kids even enjoy using it to manage 
                            their allowances. Total game-changer for family finances."
                        </div>
                        <div className="landing-testimonial-rating">★★★★★</div>
                    </div>

                    <div className="landing-testimonial-card">
                        <div className="landing-testimonial-header">
                            <div className="landing-testimonial-avatar">DL</div>
                            <div className="landing-testimonial-info">
                                <h4>David Lopez</h4>
                                <p>Freelance Designer, New York</p>
                            </div>
                        </div>
                        <div className="landing-testimonial-content">
                            "I've tried every budgeting app out there, and this is the only one I've stuck with. The AI chat is incredibly 
                            helpful for understanding my irregular freelance income. Reports are beautiful and the insights are actually 
                            actionable. Worth every penny and more."
                        </div>
                        <div className="landing-testimonial-rating">★★★★★</div>
                    </div>

                    <div className="landing-testimonial-card">
                        <div className="landing-testimonial-header">
                            <div className="landing-testimonial-avatar">RT</div>
                            <div className="landing-testimonial-info">
                                <h4>Rachel Thompson</h4>
                                <p>Teacher, Chicago</p>
                            </div>
                        </div>
                        <div className="landing-testimonial-content">
                            "On a teacher's salary, every dollar counts. This platform helped me identify where I was overspending and 
                            create a realistic budget. The voice input feature is perfect for quickly adding expenses on the go. 
                            I've built up a $3,000 emergency fund in just 6 months!"
                        </div>
                        <div className="landing-testimonial-rating">★★★★★</div>
                    </div>

                    <div className="landing-testimonial-card">
                        <div className="landing-testimonial-header">
                            <div className="landing-testimonial-avatar">JK</div>
                            <div className="landing-testimonial-info">
                                <h4>James Kim</h4>
                                <p>Graduate Student, Boston</p>
                            </div>
                        </div>
                        <div className="landing-testimonial-content">
                            "Perfect for students! The free tier has everything I need. Receipt scanning saves me from losing paper receipts, 
                            and the AI helps me understand where my student loans are going. The insights helped me cut my food spending by 
                            40% without feeling deprived. Highly recommend!"
                        </div>
                        <div className="landing-testimonial-rating">★★★★★</div>
                    </div>
                </div>
            </section>

            {/* Household Collaboration Section */}
            <section className="landing-section" style={{ background: 'var(--card-bg)', padding: '100px 20px' }}>
                <h2 className="landing-section-title">Perfect for Every Type of Household</h2>
                <p className="landing-section-subtitle">
                    Whether you're managing solo finances, budgeting with a partner, coordinating family expenses, 
                    or splitting bills with roommates — our platform adapts to your needs seamlessly.
                </p>

                <div style={{ display: 'flex', gap: '40px', justifyContent: 'center', flexWrap: 'wrap', marginTop: '50px' }}>
                    <div className="landing-benefit-item" style={{ maxWidth: '450px' }}>
                        <div className="icon"><Users size={56} /></div>
                        <h4>Create a New Household</h4>
                        <p>
                            Start fresh with your own household. Invite unlimited members. Set shared budgets and goals. 
                            Perfect for families, couples, roommates, or small teams managing shared expenses.
                        </p>
                    </div>
                    <div className="landing-benefit-item" style={{ maxWidth: '450px' }}>
                        <div className="icon"><Shield size={56} /></div>
                        <h4>Join an Existing Household</h4>
                        <p>
                            Received an invite code? Join a household instantly and start collaborating. 
                            All members can track expenses, view reports, and chat with the AI advisor while maintaining privacy settings.
                        </p>
                    </div>
                </div>

                {/* 
                    ============================================
                    IMAGE PLACEHOLDER: Household Collaboration
                    ============================================
                    Recommended image: 
                    - Screenshot showing household members view
                    - Display multiple users, shared expenses, and collaboration features
                    - Dimensions: 1000x600px
                */}
                <div className="landing-screenshot-container" style={{ marginTop: '50px' }}>
                    <div className="landing-screenshot">
                        👨‍👩‍👧‍👦 Household Collaboration Screenshot
                        <br />
                        (Multi-user interface with shared expenses)
                    </div>
                </div>
            </section>

            {/* FAQ Section */}
            <section className="landing-faq-section">
                <h2 className="landing-section-title">Frequently Asked Questions</h2>
                <p className="landing-section-subtitle">
                    Everything you need to know about our platform
                </p>
                
                <div className="landing-faq-list">
                    <div className="landing-faq-item">
                        <div className="landing-faq-question">
                            <CheckCircle size={20} style={{ color: 'var(--primary)', marginRight: '10px', display: 'inline' }} />
                            Is my financial data secure and private?
                        </div>
                        <div className="landing-faq-answer">
                            Absolutely. We use bank-level 256-bit AES encryption, are SOC 2 Type II certified, and perform daily automated backups. 
                            Your data is stored on secure servers with enterprise-grade protection. We never sell your data to third parties, 
                            and you maintain complete control over your information. You can export or delete your data at any time.
                        </div>
                    </div>

                    <div className="landing-faq-item">
                        <div className="landing-faq-question">
                            <CheckCircle size={20} style={{ color: 'var(--primary)', marginRight: '10px', display: 'inline' }} />
                            How does the AI categorization actually work?
                        </div>
                        <div className="landing-faq-answer">
                            Our AI uses advanced natural language processing and machine learning to analyze transaction descriptions, amounts, 
                            merchants, and spending patterns. It automatically categorizes expenses into Needs, Wants, and Savings with 99% accuracy. 
                            The system learns from your corrections and gets smarter over time. It can process voice input, OCR-scanned receipts, 
                            text entries, and bulk uploads — all with zero manual categorization required.
                        </div>
                    </div>

                    <div className="landing-faq-item">
                        <div className="landing-faq-question">
                            <CheckCircle size={20} style={{ color: 'var(--primary)', marginRight: '10px', display: 'inline' }} />
                            Can I use this platform with my family or roommates?
                        </div>
                        <div className="landing-faq-answer">
                            Yes! Our household feature is specifically designed for collaboration. Create a household and invite unlimited members — 
                            family, partners, roommates, or teams. Everyone can track expenses, view shared reports, and chat with the AI advisor. 
                            You can set individual privacy settings while still sharing household-level insights and budgets.
                        </div>
                    </div>

                    <div className="landing-faq-item">
                        <div className="landing-faq-question">
                            <CheckCircle size={20} style={{ color: 'var(--primary)', marginRight: '10px', display: 'inline' }} />
                            Do you have a mobile app?
                        </div>
                        <div className="landing-faq-answer">
                            Our platform is fully responsive and works seamlessly on mobile browsers with all features available. 
                            Native iOS and Android apps are currently in beta testing and will be released in Q2 2026. 
                            Sign up now to get early access when they launch!
                        </div>
                    </div>

                    <div className="landing-faq-item">
                        <div className="landing-faq-question">
                            <CheckCircle size={20} style={{ color: 'var(--primary)', marginRight: '10px', display: 'inline' }} />
                            How much does it cost? Is there a free version?
                        </div>
                        <div className="landing-faq-answer">
                            Yes! We offer a generous free tier that includes all core features: unlimited transactions, AI categorization, 
                            basic reports, and household collaboration. Our Premium plan ($9.99/month) adds advanced analytics, unlimited AI 
                            chat sessions, custom report generation, priority support, and export to Excel/PDF. Enterprise plans available for 
                            organizations. All plans come with a 30-day money-back guarantee.
                        </div>
                    </div>

                    <div className="landing-faq-item">
                        <div className="landing-faq-question">
                            <CheckCircle size={20} style={{ color: 'var(--primary)', marginRight: '10px', display: 'inline' }} />
                            Can I import my existing financial data?
                        </div>
                        <div className="landing-faq-answer">
                            Absolutely! You can import data from Excel, CSV, or other budgeting apps. Our AI automatically maps columns, 
                            categorizes transactions, and merges duplicates. We support bulk imports of thousands of transactions at once. 
                            You can also manually add past expenses or connect future transactions through our various input methods.
                        </div>
                    </div>

                    <div className="landing-faq-item">
                        <div className="landing-faq-question">
                            <CheckCircle size={20} style={{ color: 'var(--primary)', marginRight: '10px', display: 'inline' }} />
                            What makes your AI different from other budget apps?
                        </div>
                        <div className="landing-faq-answer">
                            Our RAG-powered Financial Advisor AI is unique in the industry. Unlike generic chatbots, it actually reads and 
                            understands YOUR specific transaction history, spending patterns, and financial situation. It provides personalized, 
                            context-aware advice based on your real data — not generic tips. Combined with our Smart Categorization and Report 
                            Generation systems, you get a truly intelligent financial management platform that thinks and learns.
                        </div>
                    </div>

                    <div className="landing-faq-item">
                        <div className="landing-faq-question">
                            <CheckCircle size={20} style={{ color: 'var(--primary)', marginRight: '10px', display: 'inline' }} />
                            Can I cancel anytime? What happens to my data?
                        </div>
                        <div className="landing-faq-answer">
                            Yes, you can cancel anytime with no penalties or hidden fees. If you're on a paid plan, you'll have access until 
                            the end of your billing period. Your data remains accessible even after cancellation. You can export everything to 
                            Excel/CSV format, and we'll retain your data for 90 days in case you want to return. After that, it's permanently 
                            deleted per your request. You're always in control.
                        </div>
                    </div>
                </div>
            </section>

            {/* Final CTA */}
            <section className="landing-cta-section">
                <h2>🌟 Start Your Financial Transformation Today</h2>
                <p>
                    Join over 10,000 households already taking control of their money with AI.
                    <br />
                    Start free, upgrade anytime, cancel whenever you want.
                </p>

                <div className="landing-cta-buttons">
                    <button className="landing-cta-button primary" onClick={() => navigate('/login')}>
                        Get Started Free
                    </button>
                    <button className="landing-cta-button secondary" onClick={() => navigate('/register')}>
                        Create Account
                    </button>
                </div>

                <p style={{ marginTop: '40px', fontSize: '1rem', color: 'rgba(255, 255, 255, 0.9)' }}>
                    ✓ No credit card required  •  ✓ Free forever  •  ✓ Cancel anytime  •  ✓ 30-day money-back guarantee
                </p>
            </section>

            {/* Footer */}
            <Footer />
        </div>
    );
}

export default LandingDesktop;
