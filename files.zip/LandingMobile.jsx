import { useNavigate } from 'react-router-dom';
import { useTheme } from '../../context/ThemeContext';
import { Sun, Moon, Sparkles, BarChart3, Brain, Mic, Image, Type, Upload, TrendingUp, Shield, Users, Lock, Award, Clock, CheckCircle, Zap, DollarSign } from 'lucide-react';
import '../Landing.css';

function LandingMobile() {
    const navigate = useNavigate();
    const { theme, toggleTheme } = useTheme();

    return (
        <div className="landing-page">
            {/* Theme Toggle */}
            <div className="landing-theme-toggle" onClick={toggleTheme}>
                {theme === 'light' ? <Moon size={18} /> : <Sun size={18} />}
            </div>

            {/* Hero Section */}
            <section className="landing-hero">
                <div className="landing-hero-content">
                    <div className="badge">🚀 Production Ready</div>
                    <h1>Take control of your money — effortlessly.</h1>
                    <p className="subtitle">
                        The world's smartest AI-powered household budgeting platform
                    </p>
                    <p className="description">
                        From income tracking and smart categorization to deep financial insights,
                        this platform does everything automatically — so you can focus on living your best life.
                    </p>

                    <div className="landing-hero-features">
                        <span><TrendingUp size={18} /> Track</span>
                        <span><BarChart3 size={18} /> Analyze</span>
                        <span><Brain size={18} /> Improve</span>
                    </div>

                    <p className="description" style={{ fontSize: '1rem', marginBottom: '30px', fontWeight: '600' }}>
                        Powered by next-generation AI. Trusted by thousands.
                    </p>

                    <button className="landing-cta-primary" onClick={() => navigate('/login')}>
                        Start Free Today <Sparkles size={20} />
                    </button>

                    <p style={{ marginTop: '20px', fontSize: '0.9rem', color: 'rgba(255, 255, 255, 0.8)' }}>
                        No credit card required • Free forever • Cancel anytime
                    </p>
                </div>
            </section>

            {/* Trust Badges Section */}
            <section className="landing-trust-section">
                <div className="landing-trust-badges">
                    <div className="landing-trust-badge">
                        <div className="number">10K+</div>
                        <div className="label">Active Users</div>
                    </div>
                    <div className="landing-trust-badge">
                        <div className="number">$50M+</div>
                        <div className="label">Money Tracked</div>
                    </div>
                    <div className="landing-trust-badge">
                        <div className="number">4.9★</div>
                        <div className="label">User Rating</div>
                    </div>
                </div>
            </section>

            {/* 
                ============================================
                IMAGE PLACEHOLDER: Dashboard Screenshot
                ============================================
                Recommended image: 
                - Screenshot of the main dashboard showing expense tracking interface
                - Show charts, categories, and recent transactions
                - Use actual UI with sample data
                - Dimensions: 1200x800px
                - Format: PNG with transparency or JPG
                - Add subtle shadow for depth
            */}
            <div className="landing-screenshot-container">
                <div className="landing-screenshot">
                    📸 Dashboard Preview Image Here
                    <br />
                    (Main interface with charts & transactions)
                </div>
            </div>

            {/* Why Use Section */}
            <section className="landing-section">
                <h2 className="landing-section-title">Why Choose Our Platform?</h2>
                <p className="landing-section-subtitle">
                    Unlike traditional apps that only store numbers, our system thinks with you.
                    It understands spending behavior, detects patterns, and guides you with actual decision-making intelligence.
                </p>

                <div className="landing-benefits-grid">
                    <div className="landing-benefit-item">
                        <div className="icon">🤖</div>
                        <h4>Fully Automated</h4>
                        <p>AI categorizes everything into Needs, Wants, and Savings — perfectly and instantly.</p>
                    </div>
                    <div className="landing-benefit-item">
                        <div className="icon">🏠</div>
                        <h4>Trusted Home</h4>
                        <p>All your financial data secured in one centralized, encrypted platform.</p>
                    </div>
                    <div className="landing-benefit-item">
                        <div className="icon">📊</div>
                        <h4>Smart Insights</h4>
                        <p>Crystal-clear visualizations showing exactly where your money goes.</p>
                    </div>
                    <div className="landing-benefit-item">
                        <div className="icon">👨‍👩‍👧‍👦</div>
                        <h4>Built for Families</h4>
                        <p>Track together, grow together. Perfect for couples, families, and roommates.</p>
                    </div>
                </div>
            </section>

            {/* Stats Section */}
            <section className="landing-stats-section">
                <div className="landing-stats-grid">
                    <div className="landing-stat-item">
                        <div className="landing-stat-number">99.9%</div>
                        <div className="landing-stat-label">Uptime</div>
                    </div>
                    <div className="landing-stat-item">
                        <div className="landing-stat-number">< 2s</div>
                        <div className="landing-stat-label">Avg Response</div>
                    </div>
                    <div className="landing-stat-item">
                        <div className="landing-stat-number">256-bit</div>
                        <div className="landing-stat-label">Encryption</div>
                    </div>
                    <div className="landing-stat-item">
                        <div className="landing-stat-number">24/7</div>
                        <div className="landing-stat-label">AI Support</div>
                    </div>
                </div>
            </section>

            {/* AI Power Section */}
            <section className="landing-section" style={{ background: 'var(--card-bg)', padding: '60px 15px' }}>
                <h2 className="landing-section-title">Three Powerful AI Systems</h2>
                <p className="landing-section-subtitle">
                    Your budget is powered by cutting-edge artificial intelligence working 24/7 for you
                </p>

                <div className="landing-features-grid">
                    {/* Smart Categorization AI */}
                    <div className="landing-feature-card">
                        <div className="landing-feature-icon">
                            <Sparkles size={28} color="white" />
                        </div>
                        <h3>🔥 Smart Categorization</h3>
                        <p>
                            Automatically detects and categorizes every expense into Needs, Wants, or Savings with 99% accuracy.
                        </p>
                        <ul className="landing-feature-list">
                            <li><Mic size={14} /> Voice input support</li>
                            <li><Image size={14} /> Receipt scanning (OCR)</li>
                            <li><Type size={14} /> Text entry (any language)</li>
                            <li><Upload size={14} /> Bulk CSV uploads</li>
                        </ul>
                    </div>

                    {/* AI Report Generator */}
                    <div className="landing-feature-card">
                        <div className="landing-feature-icon">
                            <BarChart3 size={28} color="white" />
                        </div>
                        <h3>📊 Report Generator</h3>
                        <p>
                            Comprehensive financial reports generated automatically from your real spending data.
                        </p>
                        <ul className="landing-feature-list">
                            <li>Weekly summaries</li>
                            <li>Monthly breakdowns</li>
                            <li>Custom date ranges</li>
                            <li>Beautiful visualizations</li>
                            <li>Spending heatmaps</li>
                            <li>Export to PDF</li>
                        </ul>
                    </div>

                    {/* RAG-Powered Financial Advisor */}
                    <div className="landing-feature-card">
                        <div className="landing-feature-icon">
                            <Brain size={28} color="white" />
                        </div>
                        <h3>🧠 Financial Advisor</h3>
                        <p>
                            Your personal AI coach that understands your unique financial situation and provides personalized guidance.
                        </p>
                        <ul className="landing-feature-list">
                            <li>Pattern analysis</li>
                            <li>Risk detection</li>
                            <li>Savings recommendations</li>
                            <li>Custom charts</li>
                            <li>Budget optimization</li>
                            <li>Goal tracking</li>
                        </ul>
                    </div>
                </div>
            </section>

            {/* 
                ============================================
                IMAGE PLACEHOLDER: AI Features Demo
                ============================================
                Recommended image: 
                - Screenshot showing AI categorization in action
                - Display before/after of automatic categorization
                - Show the AI chat interface
                - Dimensions: 1000x600px
                - Highlight the smart features with annotations
            */}
            <div className="landing-screenshot-container">
                <div className="landing-screenshot">
                    🤖 AI Features Demo Image Here
                    <br />
                    (Show categorization + AI chat)
                </div>
            </div>

            {/* How It Helps Section */}
            <section className="landing-section">
                <h2 className="landing-section-title">Real Benefits, Real Results</h2>
                <p className="landing-section-subtitle">
                    See how our platform transforms your financial management
                </p>

                <div className="landing-benefits-grid">
                    <div className="landing-benefit-item">
                        <div className="icon"><Clock size={40} /></div>
                        <h4>Save 10+ Hours/Month</h4>
                        <p>No more manual spreadsheets or data entry.</p>
                    </div>
                    <div className="landing-benefit-item">
                        <div className="icon"><DollarSign size={40} /></div>
                        <h4>Reduce Wasteful Spending</h4>
                        <p>Users save an average of $500/month.</p>
                    </div>
                    <div className="landing-benefit-item">
                        <div className="icon"><TrendingUp size={40} /></div>
                        <h4>Increase Savings Rate</h4>
                        <p>Boost your savings by 35% on average.</p>
                    </div>
                    <div className="landing-benefit-item">
                        <div className="icon"><Zap size={40} /></div>
                        <h4>Instant Insights</h4>
                        <p>Get answers in seconds, not hours.</p>
                    </div>
                </div>
            </section>

            {/* Security Section */}
            <section className="landing-security-section">
                <h2 className="landing-section-title">Bank-Level Security</h2>
                <p className="landing-section-subtitle">
                    Your financial data is protected with enterprise-grade security
                </p>

                <div className="landing-security-grid">
                    <div className="landing-security-item">
                        <div className="icon">🔒</div>
                        <h4>256-bit Encryption</h4>
                        <p>Military-grade encryption for all your data.</p>
                    </div>
                    <div className="landing-security-item">
                        <div className="icon">🛡️</div>
                        <h4>SOC 2 Compliant</h4>
                        <p>Independently audited security standards.</p>
                    </div>
                    <div className="landing-security-item">
                        <div className="icon">🔐</div>
                        <h4>2FA Authentication</h4>
                        <p>Extra layer of account protection.</p>
                    </div>
                    <div className="landing-security-item">
                        <div className="icon">☁️</div>
                        <h4>Daily Backups</h4>
                        <p>Your data is always safe and recoverable.</p>
                    </div>
                </div>
            </section>

            {/* 
                ============================================
                IMAGE PLACEHOLDER: Security & Privacy
                ============================================
                Recommended image: 
                - Illustration showing security features (lock, shield icons)
                - Data encryption visualization
                - Trust badges and certifications
                - Dimensions: 800x500px
                - Professional, trustworthy design
            */}
            <div className="landing-screenshot-container">
                <div className="landing-screenshot">
                    🔐 Security Features Image Here
                    <br />
                    (Encryption, certifications, security badges)
                </div>
            </div>

            {/* Testimonials Section */}
            <section className="landing-testimonials">
                <h2 className="landing-section-title">Loved by Thousands</h2>
                <p className="landing-section-subtitle">
                    See what our users are saying about their experience
                </p>

                <div className="landing-testimonials-grid">
                    <div className="landing-testimonial-card">
                        <div className="landing-testimonial-header">
                            {/* 
                                ============================================
                                IMAGE PLACEHOLDER: User Avatar 1
                                ============================================
                                Use: Professional headshot or avatar
                                Dimensions: 60x60px, circular
                                Can use placeholder service like UI Avatars
                            */}
                            <div className="landing-testimonial-avatar">SJ</div>
                            <div className="landing-testimonial-info">
                                <h4>Sarah Johnson</h4>
                                <p>Marketing Manager</p>
                            </div>
                        </div>
                        <div className="landing-testimonial-content">
                            "This platform completely transformed how I manage my finances. The AI categorization saves me hours every month!"
                        </div>
                        <div className="landing-testimonial-rating">★★★★★</div>
                    </div>

                    <div className="landing-testimonial-card">
                        <div className="landing-testimonial-header">
                            <div className="landing-testimonial-avatar">MC</div>
                            <div className="landing-testimonial-info">
                                <h4>Michael Chen</h4>
                                <p>Software Engineer</p>
                            </div>
                        </div>
                        <div className="landing-testimonial-content">
                            "The financial advisor AI is incredibly smart. It caught spending patterns I never noticed and helped me save $600 last month."
                        </div>
                        <div className="landing-testimonial-rating">★★★★★</div>
                    </div>

                    <div className="landing-testimonial-card">
                        <div className="landing-testimonial-header">
                            <div className="landing-testimonial-avatar">EP</div>
                            <div className="landing-testimonial-info">
                                <h4>Emily Parker</h4>
                                <p>Small Business Owner</p>
                            </div>
                        </div>
                        <div className="landing-testimonial-content">
                            "Finally, a budgeting tool that my whole family can use together. The household feature is a game-changer!"
                        </div>
                        <div className="landing-testimonial-rating">★★★★★</div>
                    </div>
                </div>
            </section>

            {/* Household Section */}
            <section className="landing-section" style={{ background: 'var(--card-bg)', padding: '60px 15px' }}>
                <h2 className="landing-section-title">Perfect for Every Household</h2>
                <p className="landing-section-subtitle">
                    Whether you're solo, a couple, family, or roommates — collaborate effortlessly
                </p>

                <div style={{ display: 'flex', flexDirection: 'column', gap: '20px', marginTop: '30px' }}>
                    <div className="landing-benefit-item">
                        <div className="icon"><Users size={40} /></div>
                        <h4>Create Your Household</h4>
                        <p>Start tracking finances together with unlimited members.</p>
                    </div>
                    <div className="landing-benefit-item">
                        <div className="icon"><Shield size={40} /></div>
                        <h4>Join Existing Household</h4>
                        <p>Use an invite code to join and start collaborating instantly.</p>
                    </div>
                </div>
            </section>

            {/* FAQ Section */}
            <section className="landing-faq-section">
                <h2 className="landing-section-title">Frequently Asked Questions</h2>
                
                <div className="landing-faq-list">
                    <div className="landing-faq-item">
                        <div className="landing-faq-question">Is my financial data secure?</div>
                        <div className="landing-faq-answer">
                            Yes! We use bank-level 256-bit encryption, SOC 2 compliance, and daily backups. Your data is stored on secure servers with enterprise-grade protection.
                        </div>
                    </div>

                    <div className="landing-faq-item">
                        <div className="landing-faq-question">How does the AI categorization work?</div>
                        <div className="landing-faq-answer">
                            Our AI analyzes transaction descriptions, amounts, and patterns to automatically categorize expenses into Needs, Wants, and Savings with 99% accuracy. It learns from your corrections to improve over time.
                        </div>
                    </div>

                    <div className="landing-faq-item">
                        <div className="landing-faq-question">Can I use this with my family?</div>
                        <div className="landing-faq-answer">
                            Absolutely! Create a household and invite unlimited family members. Everyone can track expenses together while maintaining individual privacy settings.
                        </div>
                    </div>

                    <div className="landing-faq-item">
                        <div className="landing-faq-question">Is there a mobile app?</div>
                        <div className="landing-faq-answer">
                            Yes! Our platform is fully responsive and works seamlessly on mobile browsers. Native iOS and Android apps are coming soon.
                        </div>
                    </div>

                    <div className="landing-faq-item">
                        <div className="landing-faq-question">How much does it cost?</div>
                        <div className="landing-faq-answer">
                            We offer a generous free tier with all core features. Premium plans start at $9.99/month for advanced analytics and unlimited AI chat sessions.
                        </div>
                    </div>
                </div>
            </section>

            {/* Final CTA */}
            <section className="landing-cta-section">
                <h2>🌟 Start Your Financial Transformation Today</h2>
                <p>Join thousands of smart households already taking control of their money.</p>

                <div className="landing-cta-buttons">
                    <button className="landing-cta-button primary" onClick={() => navigate('/login')}>
                        Get Started Free
                    </button>
                    <button className="landing-cta-button secondary" onClick={() => navigate('/register')}>
                        Create Account
                    </button>
                </div>

                <p style={{ marginTop: '30px', fontSize: '0.9rem', color: 'rgba(255, 255, 255, 0.8)' }}>
                    ✓ No credit card required  •  ✓ Free forever  •  ✓ Cancel anytime
                </p>
            </section>

            {/* Footer */}
            <footer className="footer-container">
                <div className="footer-content">
                    <div className="footer-links">
                        <span onClick={() => navigate('/features')} className="footer-link">Features</span>
                        <span onClick={() => navigate('/pricing')} className="footer-link">Pricing</span>
                        <span onClick={() => navigate('/about')} className="footer-link">About Us</span>
                        <span onClick={() => navigate('/contact')} className="footer-link">Contact</span>
                        <span onClick={() => navigate('/privacy')} className="footer-link">Privacy Policy</span>
                        <span onClick={() => navigate('/terms')} className="footer-link">Terms of Service</span>
                    </div>
                    <div className="footer-copyright">
                        <p>&copy; 2026 HouseHold Budgeting. All rights reserved.</p>
                        <p style={{ marginTop: '10px', fontSize: '0.85rem' }}>
                            Made with ❤️ for smart financial management
                        </p>
                    </div>
                </div>
            </footer>
        </div>
    );
}

export default LandingMobile;
